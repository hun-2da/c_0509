#include<stdio.h>
#include <stdlib.h>
// ===== ����ť �ڵ� ���� ======
int MAX_QUEUE_SIZE=1;
typedef char element;
typedef struct { // ť Ÿ��
	element *data;
	int front, rear;
} QueueType;
// ���� �Լ�
void error(char* message)
{
	fprintf(stderr, "%s\n", message);
	exit(1); //[juht]
}
// ���� ���� ���� �Լ�
void init_queue(QueueType* q)
{
	MAX_QUEUE_SIZE = 1;
	q->data = malloc(MAX_QUEUE_SIZE * sizeof(char));
	q->front = q->rear = 0;
}
// ���� ���� ���� �Լ�
int is_empty(QueueType* q)
{
	return (q->front == q->rear);
}
// ��ȭ ���� ���� �Լ�
int is_full(QueueType* q)
{
	return ((q->rear + 1) % MAX_QUEUE_SIZE == q->front);
}
// ����ť ��� �Լ�
void queue_print(QueueType* q)
{
	printf("QUEUE(front=%d rear=%d) = ", q->front, q->rear);
	if (!is_empty(q)) {
		int i = q->front;
		do {
			i = (i + 1) % (MAX_QUEUE_SIZE);
			printf("%d | ", q->data[i]);
			if (i == q->rear)
				break;
		} while (i != q->front);
	}
	printf("\n");
}
void enqueue(QueueType* q, int item)
{
	if (is_full(q)) {
		MAX_QUEUE_SIZE++;
		q->data = realloc(q->data, MAX_QUEUE_SIZE * sizeof(char));
		if (q->data == NULL) {
			fprintf(stderr, "NULL.\n");
		}
	}
	q->data[++(q->rear)] = item;
}
element delete_rear(QueueType* q)
{
	int prev = q->rear;
	if (is_empty(q))	return 0;
		//error("ť�� ��������Դϴ�");
	q->rear = (q->rear - 1 + MAX_QUEUE_SIZE) % MAX_QUEUE_SIZE;
	return q->data[prev];
}
element delete_front(QueueType* q)
{
	if (is_empty(q))	return 0;
		//error("ť�� ��������Դϴ�");
	q->front = (q->front + 1) % MAX_QUEUE_SIZE;
	return q->data[q->front];
}
int dequeue(QueueType* q) // [juht] element dequeue(QueType *q)
{
	if (is_empty(q)) {
		error("ť�� ��������Դϴ�.");
		return -1; // [juht] �ǹ� ����
	}
	int item = q->data[++(q->front)];
	return item;
}
int main(void) {
	int boolean = 1;
	while (boolean) {
		/*stack_struct s;
		in(&s);*/
		QueueType q;
		init_queue(&q);

		int number = 30;
		char* string = malloc(number * sizeof(char));

		printf("���ڿ��� �Է��Ͻÿ� : ");
		//scanf_s("%s", string,number);
		fgets(string, number, stdin);
		//fflush(stdin);

		for (int i = 0; ; i++) {
			char c = string[i];
			if (string[i] == '\n') break;

			switch (c) {
			case '\'':	case '\"':	case ' ':	case ',':	case '.':
				continue;
			}
			c = tolower(c);
			enqueue(&q,c);
			//push(&s, c);
		}
		for (int i = 0;MAX_QUEUE_SIZE/2; i++) {
			
			if (MAX_QUEUE_SIZE == -1) {
				printf("ȸ���Դϴ�.");
				break;
			}
			char c, c2;
			c = delete_front(&q);
			c2 = delete_rear(&q);
			if (c != c2) {
				printf("ȸ��X.");
				break;
			}
		}
		while (1) {
			printf("\n��� �Է��Ͻðڽ��ϱ�? (YES/NO)");
			char c[4];
			scanf_s("%s", c, 4);
			_strupr_s(c, 4);
			//printf("\n%s", c);
			if (strcmp(c, "YES") == 0)
				break;
			else if (strcmp(c, "NO") == 0) { boolean = 0; break; }
		}
		while (getchar() != '\n');
		free(q.data);
		//free();
		free(string);
	}
}